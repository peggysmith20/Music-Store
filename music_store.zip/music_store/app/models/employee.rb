class Employee < ApplicationRecord
  belongs_to :employee
end
