class Schedule < ApplicationRecord
end
