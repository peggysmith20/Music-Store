# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 0) do

  create_table "employee", primary_key: ["employee_id", "schedule_slot"], force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer "employee_id",                             null: false
    t.string  "first_name",    limit: 45
    t.string  "last_name",     limit: 45
    t.string  "job_title",     limit: 45
    t.decimal "pay",                      precision: 20
    t.string  "phone",         limit: 45
    t.integer "schedule_slot",                           null: false
    t.index ["schedule_slot"], name: "fk_Employees_schedule1_idx", using: :btree
  end

  create_table "product", primary_key: "product_id", id: :integer, force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string  "product_type", limit: 45
    t.string  "brand",        limit: 45
    t.decimal "price",                   precision: 20
    t.decimal "stock",                   precision: 20
  end

  create_table "sale", primary_key: ["transaction_id", "product_id"], force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer "transaction_id", null: false
    t.integer "product_id",     null: false
    t.index ["product_id"], name: "fk_sale_product1_idx", using: :btree
  end

  create_table "schedule", primary_key: "schedule_slot", id: :integer, force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.string "shift"
  end

  create_table "transaction", primary_key: ["transaction_id", "employee_id"], force: :cascade, options: "ENGINE=InnoDB DEFAULT CHARSET=utf8" do |t|
    t.integer  "transaction_id",              null: false
    t.string   "transaction_type", limit: 45
    t.integer  "employee_id",                 null: false
    t.datetime "date_time"
    t.index ["employee_id"], name: "fk_transactions_Employees1_idx", using: :btree
  end

  add_foreign_key "employee", "schedule", column: "schedule_slot", primary_key: "schedule_slot", name: "fk_Employees_schedule1"
  add_foreign_key "sale", "product", primary_key: "product_id", name: "fk_sale_product1"
  add_foreign_key "sale", "transaction", primary_key: "transaction_id", name: "fk_sale_transaction1"
  add_foreign_key "transaction", "employee", primary_key: "employee_id", name: "fk_transactions_Employees1"
end
